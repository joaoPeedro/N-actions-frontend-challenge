# @marketplace/design-tokens

This package serves as the **Design Foundation** and the single source of truth for all visual parameters in our applications.

## Token Hierarchy

Our tokens follow a decoupled hierarchy to isolate design values from usage intent across multiple platforms and brands:

```
Primitive Tokens (Colors/Spacing constants)
        │
        ▼
   Brand Themes (Brand-A specific mappings)
        │
        ▼
Semantic Tokens (Resolvers translating Theme to design intent)
        │
        ▼
 CSS Variables (Style mappings representing the active theme)
        │
        ▼
   Components  (Visual components inside the Design System)
        │
        ▼
  Application  (View presentation layer)
```

### 1. Primitive Tokens
Contains only raw design decisions (e.g. `gray.900`, `spacing.200`, `radius.md`) exported in `src/primitives/`. Raw values must never appear outside this layer.

### 2. Brand Themes
Map brand decisions to primitives (e.g. `brand-a` colors map `primary` to `blue.600`, and `neutral.dark` to `gray.900`).
* **Theme Contract**: All themes implement the `BrandTheme` contract defined in `src/themes/types.ts`.
* Themes are organized by concern (e.g., `themes/brand-a/colors.ts`, `spacing.ts`, etc.) to ease maintenance.

### 3. Semantic Tokens
Communicate intent and usage (e.g. `color.text.primary`, `space.layout.gutter`). Rather than importing primitive colors directly, the semantic files export factory functions (e.g., `resolveSemanticTokens(theme)`) to resolve tokens dynamically from the active Theme.

### 4. CSS Variables
A CSS file in `src/css/variables.css` maps Custom Properties representing the active theme (Brand A) to semantic vars. Different brands can distribute different CSS files without changing components.

---

## Design System Boundary & Public API

To enforce architectural cleanliness, the following boundary is established:
* **The Application (`@marketplace/app`) must NEVER import `@marketplace/design-tokens` directly.**
* **Only `@marketplace/design-system` may consume Design Tokens.** 

The public contract exposes a minimal API:
```typescript
import {
  primitiveTokens,
  semanticTokens,
  themes,
  resolveSemanticTokens,
} from "@marketplace/design-tokens";
```
