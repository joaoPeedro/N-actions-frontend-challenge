import { brandADarkTheme, brandALightTheme } from "./themes/brand-a";

export const themes = {
  brandA: {
    light: brandALightTheme,
    dark: brandADarkTheme,
  },
} as const;

export { brandADarkTheme,brandALightTheme };
export type { PrimitiveTheme } from "./contracts/primitives";
export type { SemanticTheme } from "./contracts/semantic";
export type { ResolvedTheme } from "./contracts/theme";
export type { ResolvedTheme as BrandTheme } from "./contracts/theme";
