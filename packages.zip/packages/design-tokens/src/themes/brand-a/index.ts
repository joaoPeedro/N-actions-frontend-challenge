import { brandADarkTheme } from "./themes/dark";
import { brandALightTheme } from "./themes/light";

export const themes = {
  light: brandALightTheme,
  dark: brandADarkTheme,
} as const;

export { brandADarkTheme,brandALightTheme };
export { manifest } from "./manifest";
