import type { ResolvedTheme } from "../../../../contracts/theme";
import { primitives } from "../../primitives";
import { semantic } from "./semantic";

export const brandADarkTheme: ResolvedTheme = {
  name: "brand-a",
  mode: "dark",
  primitives,
  semantic,
};
export { semantic };
