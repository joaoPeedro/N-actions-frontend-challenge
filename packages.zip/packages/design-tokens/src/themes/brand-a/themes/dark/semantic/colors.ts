import type { SemanticColors } from "../../../../../contracts/semantic";
import { colors } from "../../../primitives/colors";

export const semanticColors: SemanticColors = {
  color: {
    text: {
      primary: colors.gray[50],
      secondary: colors.gray[300],
      subtle: colors.gray[500],
      onPrimary: colors.gray[900],
    },
    surface: {
      default: colors.gray[900],
      subtle: colors.gray[800],
      card: "#1e1e1e",
    },
    border: {
      default: colors.gray[700],
      subtle: colors.gray[800],
    },
    action: {
      primary: colors.blue[500],
      primaryHover: colors.blue[600],
      danger: colors.red[500],
      dangerHover: colors.red[600],
    },
    neutrals: {
      dark: colors.gray[50],
      medium: colors.gray[300],
      light: colors.gray[700],
      extraLight: colors.gray[900],
    },
  },
};
