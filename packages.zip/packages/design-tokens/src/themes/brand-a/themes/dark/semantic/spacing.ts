import type { SemanticSpacing } from "../../../../../contracts/semantic";
import { spacing } from "../../../primitives/spacing";

export const semanticSpacing: SemanticSpacing = {
  space: {
    layout: {
      gutter: spacing[200],
      gap: spacing[300],
    },
    card: {
      padding: spacing[200],
      gap: spacing[150],
    },
  },
};
