# @marketplace/design-system

This package is the **shared component library** for the marketplace. 

## Architectural Boundary

To preserve a clean separation of concerns:
1. **Gatekeeper for Design Tokens**: The Design System is the exclusive consumer of `@marketplace/design-tokens`. The application itself must never import tokens directly from `@marketplace/design-tokens`.
2. **Component Promotion Rule**: Components (like `Button`, `Card`, `Stack`) do not exist here yet. They will only be promoted into this library when duplicate visual patterns emerge naturally in the product, preventing speculative abstractions.
