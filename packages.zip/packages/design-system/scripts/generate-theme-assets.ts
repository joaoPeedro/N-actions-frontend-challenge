import * as fs from "fs";
import * as path from "path";
import { fileURLToPath } from "url";

import { brandALightTheme } from "@marketplace/design-tokens";

import { createCSSVariables } from "../src/theme/create-css-variables";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Targets output variables.css sheet inside the design-system package root
const outputPath = path.resolve(__dirname, "../variables.css");

// Compile theme variables
const variablesCSS = createCSSVariables(brandALightTheme);

// Write variables sheet
fs.writeFileSync(outputPath, variablesCSS, "utf-8");
console.warn(`Successfully compiled active brand theme variables to ${outputPath}`);
