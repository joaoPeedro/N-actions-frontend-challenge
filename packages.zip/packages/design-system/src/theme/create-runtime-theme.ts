import type { PrimitiveTheme, ResolvedTheme, SemanticTheme } from "@marketplace/design-tokens";

export function createRuntimeTheme(
  name: string,
  mode: "light" | "dark",
  primitives: PrimitiveTheme,
  semantic: SemanticTheme
): ResolvedTheme {
  return {
    name,
    mode,
    primitives,
    semantic,
  };
}
