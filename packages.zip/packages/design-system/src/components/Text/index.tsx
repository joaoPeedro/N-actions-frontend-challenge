import type { ComponentPropsWithoutRef, ElementType, ReactNode } from "react";

export type TextSupportedTags =
  | "span"
  | "p"
  | "strong"
  | "em"
  | "h1"
  | "h2"
  | "h3"
  | "h4"
  | "h5"
  | "h6"
  | "label"
  | "li"
  | "b"
  | "i";

export type TextProps<C extends TextSupportedTags> = {
  as?: C;
  children: ReactNode;
  variant?:
    | "body"
    | "body-semibold"
    | "body-bold"
    | "heading"
    | "h1"
    | "h2"
    | "h3"
    | "subtle"
    | "caption"
    | "overline"
    | "price";
  color?: "primary" | "secondary" | "subtle" | "on-primary" | "danger" | "action";
} & Omit<ComponentPropsWithoutRef<C>, "as" | "children" | "color">;

export function Text<C extends TextSupportedTags = "span">({
  as,
  children,
  variant = "body",
  color = "primary",
  style,
  ...props
}: TextProps<C>) {
  const Component = (as || "span") as ElementType;

  // Typography font size maps
  const fontSizeMap = {
    body: "var(--ds-font-size-base)",
    "body-semibold": "var(--ds-font-size-base)",
    "body-bold": "var(--ds-font-size-base)",
    heading: "var(--ds-font-size-heading)",
    h1: "2.25rem",
    h2: "1.5rem",
    h3: "1.25rem",
    subtle: "var(--ds-font-size-base)",
    caption: "0.875rem",
    overline: "0.75rem",
    price: "1.25rem",
  };

  // Typography font weight maps
  const fontWeightMap = {
    body: "400",
    "body-semibold": "600",
    "body-bold": "700",
    heading: "700",
    h1: "800",
    h2: "700",
    h3: "700",
    subtle: "400",
    caption: "400",
    overline: "600",
    price: "700",
  };

  // Typography color maps (strictly semantic colors from our Theme Engine)
  const colorMap = {
    primary: "var(--ds-color-text-primary)",
    secondary: "var(--ds-color-text-secondary)",
    subtle: "var(--ds-color-text-subtle)",
    "on-primary": "var(--ds-color-text-on-primary)",
    danger: "var(--ds-color-action-danger)",
    action: "var(--ds-color-action-primary)",
  };

  // Typography font family maps
  const fontFamilyMap = {
    body: "var(--ds-font-family-body)",
    "body-semibold": "var(--ds-font-family-body)",
    "body-bold": "var(--ds-font-family-body)",
    heading: "var(--ds-font-family-heading)",
    h1: "var(--ds-font-family-heading)",
    h2: "var(--ds-font-family-heading)",
    h3: "var(--ds-font-family-heading)",
    subtle: "var(--ds-font-family-body)",
    caption: "var(--ds-font-family-body)",
    overline: "var(--ds-font-family-body)",
    price: "var(--ds-font-family-heading)",
  };

  return (
    <Component
      style={{
        fontFamily: fontFamilyMap[variant],
        fontSize: fontSizeMap[variant],
        fontWeight: fontWeightMap[variant],
        color: colorMap[color],
        textTransform: variant === "overline" ? "uppercase" : undefined,
        letterSpacing: variant === "overline" ? "0.05em" : undefined,
        lineHeight: (variant === "h1" || variant === "h2" || variant === "h3") ? 1.2 : undefined,
        margin: 0,
        ...style,
      }}
      {...props}
    >
      {children}
    </Component>
  );
}
