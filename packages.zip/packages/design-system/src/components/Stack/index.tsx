import type { ReactNode } from "react";

export interface StackProps {
  children: ReactNode;
  gap?: "none" | "small" | "medium" | "large";
  align?: "stretch" | "center" | "start" | "end";
  role?: string;
  style?: React.CSSProperties;
}

export function Stack({ children, gap = "medium", align = "stretch", role, style }: StackProps) {
  const gapMap = {
    none: "0",
    small: "var(--ds-space-card-gap)",
    medium: "var(--ds-space-card-padding)",
    large: "var(--ds-space-layout-gap)",
  };

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: gapMap[gap],
        alignItems: align,
        ...style,
      }}
      role={role}
    >
      {children}
    </div>
  );
}
