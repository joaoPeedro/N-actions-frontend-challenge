import type { ReactNode } from "react";

export interface SurfaceProps {
  children: ReactNode;
  variant?: "default" | "card" | "subtle";
  padding?: "none" | "small" | "medium" | "large";
  radius?: "none" | "small" | "medium" | "large";
  className?: string;
  style?: React.CSSProperties;
  role?: string;
  maxWidth?: string;
  width?: string;
}

export function Surface({
  children,
  variant = "default",
  padding = "none",
  radius = "none",
  className,
  style,
  role,
  maxWidth,
  width,
}: SurfaceProps) {
  const bgMap = {
    default: "var(--ds-color-surface-default)",
    card: "var(--ds-color-surface-card)",
    subtle: "var(--ds-color-surface-subtle)",
  };

  const paddingMap = {
    none: "0",
    small: "var(--ds-space-card-gap)",
    medium: "var(--ds-space-card-padding)",
    large: "var(--ds-space-layout-gap)",
  };

  const radiusMap = {
    none: "0px",
    small: "4px",
    medium: "8px",
    large: "12px",
  };

  const borderMap = {
    default: "none",
    card: "1px solid var(--ds-color-border-default)",
    subtle: "none",
  };

  const shadowMap = {
    default: "none",
    card: "0 1px 3px rgba(0, 0, 0, 0.05)",
    subtle: "none",
  };

  return (
    <div
      className={className}
      role={role}
      style={{
        backgroundColor: bgMap[variant],
        padding: paddingMap[padding],
        borderRadius: radiusMap[radius],
        border: borderMap[variant],
        boxShadow: shadowMap[variant],
        display: "flex",
        flexDirection: "column",
        maxWidth,
        width,
        ...style,
      }}
    >
      {children}
    </div>
  );
}
