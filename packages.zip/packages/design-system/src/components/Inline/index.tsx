import type { ReactNode } from "react";

export interface InlineProps {
  children: ReactNode;
  gap?: "none" | "small" | "medium" | "large";
  align?: "stretch" | "center" | "start" | "end" | "baseline";
  justify?: "start" | "end" | "center" | "space-between";
  wrap?: boolean;
  style?: React.CSSProperties;
}

export function Inline({
  children,
  gap = "medium",
  align = "center",
  justify = "start",
  wrap = true,
  style,
}: InlineProps) {
  const gapMap = {
    none: "0",
    small: "var(--ds-space-card-gap)",
    medium: "var(--ds-space-card-padding)",
    large: "var(--ds-space-layout-gap)",
  };

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "row",
        gap: gapMap[gap],
        alignItems: align,
        justifyContent: justify,
        flexWrap: wrap ? "wrap" : "nowrap",
        ...style,
      }}
    >
      {children}
    </div>
  );
}
