# Workspace Packages Directory

This directory hosts internal workspace packages shared across the monorepo. It isolates core UI component logic and tokens into separate modules to enable reuse and independent building.

### What belongs here

- Domain-agnostic design system packages and structural token libraries.

### What should never be added there

- Specific application routing files, business logic modules, or feature packages.
